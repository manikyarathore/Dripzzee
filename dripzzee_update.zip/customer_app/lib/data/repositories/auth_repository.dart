import 'package:firebase_auth/firebase_auth.dart';

class AuthFailure implements Exception {
  const AuthFailure(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Thin wrapper over Firebase Auth that converts error codes into messages a
/// shopper can act on.
class AuthRepository {
  AuthRepository({FirebaseAuth? auth}) : _auth = auth ?? FirebaseAuth.instance;

  final FirebaseAuth _auth;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// Also fires when profile fields (e.g. display name) change.
  Stream<User?> userChanges() => _auth.userChanges();

  /// Sends a 6-digit OTP to [phoneE164] (e.g. +919876543210).
  ///
  /// On many Android phones Firebase reads the SMS itself and signs the user
  /// in without typing the code ([onAutoVerified]).
  Future<void> sendOtp({
    required String phoneE164,
    int? resendToken,
    required void Function(String verificationId, int? resendToken) onCodeSent,
    required void Function() onAutoVerified,
    required void Function(AuthFailure failure) onError,
  }) async {
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneE164,
        timeout: const Duration(seconds: 60),
        forceResendingToken: resendToken,
        verificationCompleted: (credential) async {
          try {
            await _auth.signInWithCredential(credential);
            onAutoVerified();
          } on FirebaseAuthException catch (e) {
            onError(AuthFailure(messageForCode(e.code)));
          }
        },
        verificationFailed: (e) => onError(AuthFailure(messageForCode(e.code))),
        codeSent: onCodeSent,
        codeAutoRetrievalTimeout: (_) {},
      );
    } on FirebaseAuthException catch (e) {
      onError(AuthFailure(messageForCode(e.code)));
    } catch (_) {
      onError(const AuthFailure('Couldn\'t send the code. Please try again.'));
    }
  }

  Future<User> verifyOtp({
    required String verificationId,
    required String code,
  }) async {
    try {
      final cred = await _auth.signInWithCredential(
        PhoneAuthProvider.credential(
          verificationId: verificationId,
          smsCode: code.trim(),
        ),
      );
      return cred.user!;
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(messageForCode(e.code));
    }
  }
  User? get currentUser => _auth.currentUser;

  Future<User> signIn({required String email, required String password}) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      return cred.user!;
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(messageForCode(e.code));
    }
  }

  Future<User> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = cred.user!;
      await user.updateDisplayName(name.trim());
      return user;
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(messageForCode(e.code));
    }
  }

  /// Uses Firebase's built-in provider flow (no extra plugin). Requires the
  /// Google provider enabled + your SHA-1/SHA-256 added in Firebase console.
  Future<User> signInWithGoogle() async {
    try {
      final provider = GoogleAuthProvider()..addScope('email');
      final cred = await _auth.signInWithProvider(provider);
      return cred.user!;
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(messageForCode(e.code));
    }
  }

  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      // Don't reveal whether an account exists.
      if (e.code == 'user-not-found') return;
      throw AuthFailure(messageForCode(e.code));
    }
  }

  Future<void> signOut() => _auth.signOut();

  static String messageForCode(String code) => switch (code) {
        'email-already-in-use' =>
          'An account with this email already exists. Log in instead.',
        'invalid-email' => 'That email address doesn\'t look right.',
        'weak-password' => 'Choose a stronger password (8+ characters).',
        'user-not-found' ||
        'wrong-password' ||
        'invalid-credential' ||
        'INVALID_LOGIN_CREDENTIALS' =>
          'Incorrect email or password.',
        'invalid-verification-code' =>
          'That code isn\'t right. Check the SMS and try again.',
        'invalid-verification-id' || 'session-expired' || 'code-expired' =>
          'This code has expired. Tap "Resend code".',
        'invalid-phone-number' => 'Enter a valid 10-digit mobile number.',
        'quota-exceeded' =>
          'We\'ve sent too many codes right now. Try again in a little while.',
        'billing-not-enabled' =>
          'SMS sign-in isn\'t switched on for Dripzzee yet. Try Google instead.',
        'app-not-authorized' ||
        'missing-client-identifier' ||
        'invalid-app-credential' =>
          'This version of the app isn\'t authorised for phone sign-in yet.',
        'captcha-check-failed' || 'web-internal-error' =>
          'Verification didn\'t complete. Please try again.',
        'user-disabled' => 'This account has been disabled. Contact support.',
        'too-many-requests' =>
          'Too many attempts. Wait a few minutes and try again.',
        'network-request-failed' =>
          'No internet connection. Check your network and try again.',
        'operation-not-allowed' =>
          'This sign-in method isn\'t enabled for Dripzzee yet.',
        'web-context-canceled' ||
        'web-context-cancelled' ||
        'canceled' ||
        'cancelled' =>
          'Sign-in was cancelled.',
        'account-exists-with-different-credential' =>
          'This email is registered with a password. Log in with email instead.',
        _ => 'Something went wrong. Please try again.',
      };
}
